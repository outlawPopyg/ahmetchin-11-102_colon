module Main where

import Data.Map (Map, empty, insert, lookup)

main :: IO ()
main = do
    let myMap = insert "key1" 42 empty
    print $ Data.Map.lookup "key1" myMap  -- Выведет: Just 42
    print $ Data.Map.lookup "key2" myMap  -- Выведет: Nothing
