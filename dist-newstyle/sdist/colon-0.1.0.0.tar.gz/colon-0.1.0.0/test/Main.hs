module Main (main) where

import Test.Tasty
import Test.Tasty.HUnit
import Hedgehog
import qualified Hedgehog.Gen as Gen
import qualified Hedgehog.Range as Range
import Interpreter (interpret, initialState, InterpreterState(..))
import Types (Program(..), Cmd(..))

import Test.Tasty.Hedgehog (testProperty)

main = defaultMain tests

tests :: TestTree
tests = testGroup "Tests" [testList ]



testList :: TestTree
testList = testGroup "List"
    [ testProperty "len (drop k xs) < len xs" $ property $ do
        xs <- forAll $ Gen.list (Range.linear 1 100) Gen.alpha
        k <- forAll $ Gen.int (Range.linear 0 10)
        let n' = length $ drop k xs
            n = length xs
        diff n' (<) n

    ]

